import { useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/layout";
import CalculatorWidget from "@/components/calculator-widget";
import CalculatorCategories from "@/components/calculator-categories";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");

  const popularSearches = ["BMI Calculator", "Mortgage Calculator", "Percentage Calculator"];

  const handlePopularSearch = (term: string) => {
    setSearchQuery(term);
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <section className="mb-12">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-4xl font-bold text-slate-900 mb-4">
                Free Online Calculators
              </h2>
              <p className="text-lg text-slate-600 mb-6">
                Access over 200 calculators for finance, math, health, and everyday calculations. 
                No registration required - completely free.
              </p>

              {/* Search Bar */}
              <div className="relative mb-6">
                <Input
                  type="text"
                  placeholder="Search for calculators..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 h-12 text-base"
                />
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 h-5 w-5" />
              </div>

              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-slate-700 text-sm font-medium">Popular:</span>
                {popularSearches.map((term) => (
                  <Badge
                    key={term}
                    variant="secondary"
                    className="cursor-pointer hover:bg-primary hover:text-white transition-colors"
                    onClick={() => handlePopularSearch(term)}
                  >
                    {term}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Featured Calculator Widget */}
            <div className="flex justify-center">
              <CalculatorWidget />
            </div>
          </div>
        </section>

        {/* Calculator Categories */}
        <section>
          <h2 className="text-3xl font-bold text-center mb-12">Calculator Categories</h2>
          <CalculatorCategories searchQuery={searchQuery} />
        </section>

        {/* Stats Section */}
        <section className="bg-white rounded-xl shadow-lg border border-slate-200 p-8 mb-12 mt-16">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-4">Trusted by Millions</h2>
            <p className="text-slate-600">Providing accurate calculations since 2007</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">200+</div>
              <div className="text-slate-600">Calculators</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-health mb-2">10M+</div>
              <div className="text-slate-600">Monthly Users</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-math mb-2">100M+</div>
              <div className="text-slate-600">Calculations</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-other mb-2">15+</div>
              <div className="text-slate-600">Years Online</div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-gradient-to-r from-primary to-blue-700 rounded-xl text-white p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Need a Specific Calculator?</h2>
          <p className="text-blue-100 mb-6">
            Can't find what you're looking for? Browse our complete collection of calculators or use the search feature.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-primary hover:bg-blue-50">
              Browse All Calculators
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-blue-600">
              Request New Calculator
            </Button>
          </div>
        </section>
      </div>
    </Layout>
  );
}
