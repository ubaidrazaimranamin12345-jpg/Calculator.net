import { useState } from "react";
import { useRoute } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Layout from "@/components/layout";
import { getCalculatorById } from "@/lib/calculator-data";
import { FinancialCalculator, HealthCalculator, MathCalculator, UtilityCalculator } from "@/lib/calculator-utils";
import { useForm } from "react-hook-form";
import { ArrowLeft, Info } from "lucide-react";
import { Link } from "wouter";

export default function CalculatorPage() {
  const [, params] = useRoute("/calculator/:id");
  const calculatorId = params?.id;
  const calculator = calculatorId ? getCalculatorById(calculatorId) : null;
  
  const [results, setResults] = useState<any>(null);
  const { register, handleSubmit, watch, formState: { errors } } = useForm();

  if (!calculator) {
    return (
      <Layout>
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Calculator Not Found</h1>
            <Link href="/">
              <Button>← Back to Home</Button>
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  const IconComponent = calculator.icon;

  const onSubmit = (data: any) => {
    try {
      let result;
      
      switch (calculator.id) {
        case 'mortgage':
          result = FinancialCalculator.calculateMortgage(
            parseFloat(data.principal),
            parseFloat(data.rate),
            parseFloat(data.years)
          );
          break;
          
        case 'interest':
          result = FinancialCalculator.calculateCompoundInterest(
            parseFloat(data.principal),
            parseFloat(data.rate),
            parseFloat(data.time),
            parseFloat(data.compound) || 12
          );
          break;
          
        case 'bmi':
          result = HealthCalculator.calculateBMI(
            parseFloat(data.weight),
            parseFloat(data.height),
            data.unit
          );
          break;
          
        case 'bmr':
          result = HealthCalculator.calculateBMR(
            parseFloat(data.weight),
            parseFloat(data.height),
            parseFloat(data.age),
            data.gender,
            data.unit
          );
          break;
          
        case 'percentage':
          if (data.operation === 'calculate') {
            result = {
              result: MathCalculator.calculatePercentage(parseFloat(data.value), parseFloat(data.percentage))
            };
          } else if (data.operation === 'increase') {
            result = {
              result: MathCalculator.percentageIncrease(parseFloat(data.original), parseFloat(data.newValue))
            };
          }
          break;
          
        case 'age':
          result = UtilityCalculator.calculateAge(new Date(data.birthDate));
          break;
          
        case 'password':
          result = {
            password: UtilityCalculator.generatePassword(
              parseInt(data.length),
              data.includeNumbers,
              data.includeSymbols,
              data.includeUppercase
            )
          };
          break;
          
        default:
          result = { error: "Calculator not implemented yet" };
      }
      
      setResults(result);
    } catch (error) {
      setResults({ error: "Invalid input values" });
    }
  };

  const renderCalculatorForm = () => {
    switch (calculator.id) {
      case 'mortgage':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="principal">Loan Amount ($)</Label>
              <Input
                id="principal"
                type="number"
                step="1000"
                {...register("principal", { required: true, min: 1 })}
                placeholder="300000"
              />
            </div>
            <div>
              <Label htmlFor="rate">Annual Interest Rate (%)</Label>
              <Input
                id="rate"
                type="number"
                step="0.01"
                {...register("rate", { required: true, min: 0 })}
                placeholder="3.5"
              />
            </div>
            <div>
              <Label htmlFor="years">Loan Term (Years)</Label>
              <Input
                id="years"
                type="number"
                {...register("years", { required: true, min: 1, max: 50 })}
                placeholder="30"
              />
            </div>
          </div>
        );

      case 'bmi':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="unit">Unit System</Label>
              <Select {...register("unit")} defaultValue="metric">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="metric">Metric (kg/m)</SelectItem>
                  <SelectItem value="imperial">Imperial (lbs/in)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="weight">Weight {watch("unit") === "imperial" ? "(lbs)" : "(kg)"}</Label>
              <Input
                id="weight"
                type="number"
                step="0.1"
                {...register("weight", { required: true, min: 1 })}
                placeholder={watch("unit") === "imperial" ? "150" : "70"}
              />
            </div>
            <div>
              <Label htmlFor="height">Height {watch("unit") === "imperial" ? "(inches)" : "(meters)"}</Label>
              <Input
                id="height"
                type="number"
                step={watch("unit") === "imperial" ? "1" : "0.01"}
                {...register("height", { required: true, min: 0.1 })}
                placeholder={watch("unit") === "imperial" ? "70" : "1.75"}
              />
            </div>
          </div>
        );

      case 'percentage':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="operation">Operation</Label>
              <Select {...register("operation")} defaultValue="calculate">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="calculate">Calculate Percentage</SelectItem>
                  <SelectItem value="increase">Percentage Increase</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {watch("operation") === "calculate" ? (
              <>
                <div>
                  <Label htmlFor="value">Value</Label>
                  <Input
                    id="value"
                    type="number"
                    {...register("value", { required: true })}
                    placeholder="100"
                  />
                </div>
                <div>
                  <Label htmlFor="percentage">Percentage (%)</Label>
                  <Input
                    id="percentage"
                    type="number"
                    step="0.01"
                    {...register("percentage", { required: true })}
                    placeholder="25"
                  />
                </div>
              </>
            ) : (
              <>
                <div>
                  <Label htmlFor="original">Original Value</Label>
                  <Input
                    id="original"
                    type="number"
                    {...register("original", { required: true })}
                    placeholder="100"
                  />
                </div>
                <div>
                  <Label htmlFor="newValue">New Value</Label>
                  <Input
                    id="newValue"
                    type="number"
                    {...register("newValue", { required: true })}
                    placeholder="125"
                  />
                </div>
              </>
            )}
          </div>
        );

      case 'age':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="birthDate">Birth Date</Label>
              <Input
                id="birthDate"
                type="date"
                {...register("birthDate", { required: true })}
              />
            </div>
          </div>
        );

      case 'password':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="length">Password Length</Label>
              <Input
                id="length"
                type="number"
                {...register("length", { required: true, min: 4, max: 128 })}
                defaultValue="12"
              />
            </div>
            <div className="space-y-2">
              <Label>Options</Label>
              <div className="flex flex-col space-y-2">
                <label className="flex items-center space-x-2">
                  <input type="checkbox" {...register("includeUppercase")} defaultChecked />
                  <span>Include uppercase letters</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" {...register("includeNumbers")} defaultChecked />
                  <span>Include numbers</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" {...register("includeSymbols")} />
                  <span>Include symbols</span>
                </label>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-8">
            <Info className="h-12 w-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600">This calculator is coming soon!</p>
          </div>
        );
    }
  };

  const renderResults = () => {
    if (!results) return null;

    if (results.error) {
      return (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="pt-6">
            <p className="text-red-600">{results.error}</p>
          </CardContent>
        </Card>
      );
    }

    switch (calculator.id) {
      case 'mortgage':
        return (
          <Card>
            <CardHeader>
              <CardTitle>Mortgage Calculation Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-slate-600">Monthly Payment</p>
                  <p className="text-2xl font-bold text-primary">${results.monthlyPayment.toLocaleString()}</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-slate-600">Total Interest</p>
                  <p className="text-2xl font-bold text-green-600">${results.totalInterest.toLocaleString()}</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <p className="text-sm text-slate-600">Total Amount</p>
                  <p className="text-2xl font-bold text-purple-600">${results.totalAmount.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        );

      case 'bmi':
        return (
          <Card>
            <CardHeader>
              <CardTitle>BMI Calculation Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center p-6 bg-blue-50 rounded-lg">
                <p className="text-sm text-slate-600 mb-2">Your BMI</p>
                <p className="text-4xl font-bold text-primary mb-2">{results.bmi}</p>
                <Badge 
                  variant={results.category === 'Normal weight' ? 'default' : 'secondary'}
                  className="text-sm"
                >
                  {results.category}
                </Badge>
              </div>
            </CardContent>
          </Card>
        );

      case 'percentage':
        return (
          <Card>
            <CardHeader>
              <CardTitle>Percentage Calculation Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center p-6 bg-blue-50 rounded-lg">
                <p className="text-sm text-slate-600 mb-2">Result</p>
                <p className="text-4xl font-bold text-primary">{results.result.toFixed(2)}{watch("operation") === "increase" ? "%" : ""}</p>
              </div>
            </CardContent>
          </Card>
        );

      case 'age':
        return (
          <Card>
            <CardHeader>
              <CardTitle>Age Calculation Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-2xl font-bold text-primary">{results.years}</p>
                  <p className="text-sm text-slate-600">Years</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">{results.months}</p>
                  <p className="text-sm text-slate-600">Months</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <p className="text-2xl font-bold text-purple-600">{results.days}</p>
                  <p className="text-sm text-slate-600">Days</p>
                </div>
              </div>
            </CardContent>
          </Card>
        );

      case 'password':
        return (
          <Card>
            <CardHeader>
              <CardTitle>Generated Password</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-4 bg-slate-50 rounded-lg">
                <p className="font-mono text-lg break-all select-all">{results.password}</p>
              </div>
              <p className="text-sm text-slate-600 mt-2">Click to select and copy the password</p>
            </CardContent>
          </Card>
        );

      default:
        return null;
    }
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          
          <div className="flex items-center gap-4 mb-4">
            <div className={`w-12 h-12 bg-${calculator.category} rounded-lg flex items-center justify-center`}>
              <IconComponent className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">{calculator.name}</h1>
              <p className="text-slate-600">{calculator.description}</p>
            </div>
          </div>
          
          <div className="flex gap-2">
            {calculator.popular && (
              <Badge variant="secondary">⭐ Popular</Badge>
            )}
            {calculator.trending && (
              <Badge variant="secondary">🔥 Trending</Badge>
            )}
            <Badge variant="outline" className={`text-${calculator.category} border-${calculator.category}/20`}>
              {calculator.category}
            </Badge>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Calculator Form */}
          <Card>
            <CardHeader>
              <CardTitle>Calculator Input</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                {renderCalculatorForm()}
                <Separator />
                <Button type="submit" className="w-full">
                  Calculate
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Results */}
          <div className="space-y-6">
            {renderResults()}
            
            {/* Help/Info Card */}
            <Card className="bg-slate-50">
              <CardHeader>
                <CardTitle className="text-lg">How to Use</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 mb-4">
                  Fill in the required fields on the left and click "Calculate" to see your results.
                </p>
                <div className="space-y-2 text-sm">
                  <h4 className="font-medium">Tips:</h4>
                  <ul className="list-disc list-inside space-y-1 text-slate-600">
                    <li>All calculations are performed instantly</li>
                    <li>Results are rounded for readability</li>
                    <li>Use decimal points for precise values</li>
                    <li>Clear the form to start a new calculation</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
