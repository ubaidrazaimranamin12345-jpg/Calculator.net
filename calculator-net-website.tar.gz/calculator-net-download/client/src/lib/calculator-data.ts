import { 
  Calculator, 
  Home, 
  Car, 
  Percent, 
  PiggyBank, 
  Heart, 
  Activity, 
  Baby, 
  Scale, 
  Divide, 
  Square, 
  Shapes, 
  Calendar, 
  Clock, 
  GraduationCap, 
  Key,
  TrendingUp,
  Flame
} from "lucide-react";

export interface CalculatorItem {
  id: string;
  name: string;
  description: string;
  category: 'financial' | 'health' | 'math' | 'other';
  icon: any;
  popular?: boolean;
  trending?: boolean;
  path: string;
}

export const calculators: CalculatorItem[] = [
  // Financial Calculators
  {
    id: 'mortgage',
    name: 'Mortgage Calculator',
    description: 'Calculate monthly mortgage payments, interest, and amortization schedules.',
    category: 'financial',
    icon: Home,
    popular: true,
    path: '/calculator/mortgage'
  },
  {
    id: 'auto-loan',
    name: 'Auto Loan Calculator',
    description: 'Determine car loan payments and total interest costs.',
    category: 'financial',
    icon: Car,
    trending: true,
    path: '/calculator/auto-loan'
  },
  {
    id: 'interest',
    name: 'Interest Calculator',
    description: 'Calculate simple and compound interest on investments.',
    category: 'financial',
    icon: TrendingUp,
    path: '/calculator/interest'
  },
  {
    id: 'retirement',
    name: 'Retirement Calculator',
    description: 'Plan your retirement savings and investment strategy.',
    category: 'financial',
    icon: PiggyBank,
    path: '/calculator/retirement'
  },

  // Health & Fitness Calculators
  {
    id: 'bmi',
    name: 'BMI Calculator',
    description: 'Calculate your Body Mass Index and health category.',
    category: 'health',
    icon: Scale,
    popular: true,
    path: '/calculator/bmi'
  },
  {
    id: 'calorie',
    name: 'Calorie Calculator',
    description: 'Determine daily calorie needs for weight goals.',
    category: 'health',
    icon: Flame,
    trending: true,
    path: '/calculator/calorie'
  },
  {
    id: 'bmr',
    name: 'BMR Calculator',
    description: 'Calculate Basal Metabolic Rate and daily energy expenditure.',
    category: 'health',
    icon: Activity,
    path: '/calculator/bmr'
  },
  {
    id: 'pregnancy',
    name: 'Pregnancy Calculator',
    description: 'Calculate due dates, conception dates, and pregnancy milestones.',
    category: 'health',
    icon: Baby,
    path: '/calculator/pregnancy'
  },

  // Math Calculators
  {
    id: 'percentage',
    name: 'Percentage Calculator',
    description: 'Calculate percentages, percentage increase/decrease.',
    category: 'math',
    icon: Percent,
    popular: true,
    path: '/calculator/percentage'
  },
  {
    id: 'fraction',
    name: 'Fraction Calculator',
    description: 'Add, subtract, multiply and divide fractions.',
    category: 'math',
    icon: Divide,
    path: '/calculator/fraction'
  },
  {
    id: 'scientific',
    name: 'Scientific Calculator',
    description: 'Advanced mathematical functions and operations.',
    category: 'math',
    icon: Square,
    path: '/calculator/scientific'
  },
  {
    id: 'triangle',
    name: 'Triangle Calculator',
    description: 'Calculate triangle sides, angles, and area.',
    category: 'math',
    icon: Shapes,
    path: '/calculator/triangle'
  },

  // Other Calculators
  {
    id: 'age',
    name: 'Age Calculator',
    description: 'Calculate exact age in years, months, and days.',
    category: 'other',
    icon: Calendar,
    popular: true,
    path: '/calculator/age'
  },
  {
    id: 'date',
    name: 'Date Calculator',
    description: 'Add or subtract days, weeks, months from dates.',
    category: 'other',
    icon: Clock,
    path: '/calculator/date'
  },
  {
    id: 'gpa',
    name: 'GPA Calculator',
    description: 'Calculate Grade Point Average for students.',
    category: 'other',
    icon: GraduationCap,
    path: '/calculator/gpa'
  },
  {
    id: 'password',
    name: 'Password Generator',
    description: 'Generate secure passwords with custom criteria.',
    category: 'other',
    icon: Key,
    path: '/calculator/password'
  },
];

export const getCalculatorsByCategory = (category: string) => {
  return calculators.filter(calc => calc.category === category);
};

export const getCalculatorById = (id: string) => {
  return calculators.find(calc => calc.id === id);
};

export const searchCalculators = (query: string) => {
  const lowercaseQuery = query.toLowerCase();
  return calculators.filter(calc => 
    calc.name.toLowerCase().includes(lowercaseQuery) ||
    calc.description.toLowerCase().includes(lowercaseQuery)
  );
};
