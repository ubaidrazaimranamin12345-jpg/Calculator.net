// Basic Calculator Utils
export class BasicCalculator {
  static evaluate(expression: string): number {
    try {
      // Remove any non-mathematical characters and evaluate
      const sanitized = expression.replace(/[^0-9+\-*/.() ]/g, '');
      return Function(`"use strict"; return (${sanitized})`)();
    } catch (error) {
      throw new Error('Invalid expression');
    }
  }

  static formatNumber(num: number): string {
    if (isNaN(num) || !isFinite(num)) return 'Error';
    
    // Format with appropriate decimal places
    if (num % 1 === 0) return num.toString();
    return parseFloat(num.toFixed(10)).toString();
  }
}

// Financial Calculator Utils
export class FinancialCalculator {
  static calculateMortgage(principal: number, rate: number, years: number) {
    const monthlyRate = rate / 100 / 12;
    const numPayments = years * 12;
    
    if (monthlyRate === 0) {
      return {
        monthlyPayment: principal / numPayments,
        totalInterest: 0,
        totalAmount: principal
      };
    }
    
    const monthlyPayment = principal * 
      (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / 
      (Math.pow(1 + monthlyRate, numPayments) - 1);
    
    const totalAmount = monthlyPayment * numPayments;
    const totalInterest = totalAmount - principal;
    
    return {
      monthlyPayment: Math.round(monthlyPayment * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
      totalAmount: Math.round(totalAmount * 100) / 100
    };
  }

  static calculateCompoundInterest(principal: number, rate: number, time: number, compound: number = 12) {
    const amount = principal * Math.pow(1 + rate / 100 / compound, compound * time);
    const interest = amount - principal;
    
    return {
      finalAmount: Math.round(amount * 100) / 100,
      interestEarned: Math.round(interest * 100) / 100
    };
  }
}

// Health Calculator Utils
export class HealthCalculator {
  static calculateBMI(weight: number, height: number, unit: 'metric' | 'imperial' = 'metric') {
    let bmi: number;
    
    if (unit === 'imperial') {
      // weight in pounds, height in inches
      bmi = (weight * 703) / (height * height);
    } else {
      // weight in kg, height in meters
      bmi = weight / (height * height);
    }
    
    let category: string;
    if (bmi < 18.5) category = 'Underweight';
    else if (bmi < 25) category = 'Normal weight';
    else if (bmi < 30) category = 'Overweight';
    else category = 'Obese';
    
    return {
      bmi: Math.round(bmi * 10) / 10,
      category
    };
  }

  static calculateBMR(weight: number, height: number, age: number, gender: 'male' | 'female', unit: 'metric' | 'imperial' = 'metric') {
    let bmr: number;
    
    if (unit === 'imperial') {
      // Mifflin-St Jeor Equation (Imperial)
      if (gender === 'male') {
        bmr = (4.536 * weight) + (15.88 * height) - (5 * age) + 5;
      } else {
        bmr = (4.536 * weight) + (15.88 * height) - (5 * age) - 161;
      }
    } else {
      // Mifflin-St Jeor Equation (Metric)
      if (gender === 'male') {
        bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5;
      } else {
        bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161;
      }
    }
    
    return Math.round(bmr);
  }
}

// Math Calculator Utils
export class MathCalculator {
  static calculatePercentage(value: number, percentage: number): number {
    return (value * percentage) / 100;
  }

  static percentageIncrease(original: number, newValue: number): number {
    return ((newValue - original) / original) * 100;
  }

  static percentageDecrease(original: number, newValue: number): number {
    return ((original - newValue) / original) * 100;
  }

  static addFractions(num1: number, den1: number, num2: number, den2: number) {
    const numerator = (num1 * den2) + (num2 * den1);
    const denominator = den1 * den2;
    const gcd = this.findGCD(Math.abs(numerator), Math.abs(denominator));
    
    return {
      numerator: numerator / gcd,
      denominator: denominator / gcd
    };
  }

  static findGCD(a: number, b: number): number {
    return b === 0 ? a : this.findGCD(b, a % b);
  }
}

// Utility Calculator Utils
export class UtilityCalculator {
  static calculateAge(birthDate: Date): { years: number; months: number; days: number } {
    const today = new Date();
    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    let days = today.getDate() - birthDate.getDate();
    
    if (days < 0) {
      months--;
      days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
    }
    
    if (months < 0) {
      years--;
      months += 12;
    }
    
    return { years, months, days };
  }

  static addDaysToDate(date: Date, days: number): Date {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  static calculateGPA(grades: { grade: number; credits: number }[]): number {
    const totalPoints = grades.reduce((sum, course) => sum + (course.grade * course.credits), 0);
    const totalCredits = grades.reduce((sum, course) => sum + course.credits, 0);
    
    return totalCredits > 0 ? Math.round((totalPoints / totalCredits) * 100) / 100 : 0;
  }

  static generatePassword(length: number, includeNumbers: boolean, includeSymbols: boolean, includeUppercase: boolean): string {
    let charset = 'abcdefghijklmnopqrstuvwxyz';
    if (includeUppercase) charset += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (includeNumbers) charset += '0123456789';
    if (includeSymbols) charset += '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    let password = '';
    for (let i = 0; i < length; i++) {
      password += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    
    return password;
  }
}
