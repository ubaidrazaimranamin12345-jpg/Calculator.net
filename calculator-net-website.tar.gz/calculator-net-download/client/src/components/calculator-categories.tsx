import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { calculators, getCalculatorsByCategory } from "@/lib/calculator-data";
import { ChartLine, Heart, Calculator, Settings } from "lucide-react";

const categoryInfo = {
  financial: {
    title: "Financial Calculators",
    icon: ChartLine,
    color: "financial",
    bgColor: "bg-financial",
    description: "Calculate mortgages, loans, interest, and investments"
  },
  health: {
    title: "Health & Fitness Calculators", 
    icon: Heart,
    color: "health",
    bgColor: "bg-health",
    description: "Track your health metrics and fitness goals"
  },
  math: {
    title: "Math Calculators",
    icon: Calculator,
    color: "math", 
    bgColor: "bg-math",
    description: "Solve mathematical problems and equations"
  },
  other: {
    title: "Other Calculators",
    icon: Settings,
    color: "other",
    bgColor: "bg-other",
    description: "Useful tools for everyday calculations"
  }
};

interface CalculatorCategoriesProps {
  searchQuery?: string;
}

export default function CalculatorCategories({ searchQuery = "" }: CalculatorCategoriesProps) {
  const getFilteredCalculators = (category: string) => {
    let categoryCalculators = getCalculatorsByCategory(category);
    
    if (searchQuery) {
      categoryCalculators = categoryCalculators.filter(calc =>
        calc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        calc.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    return categoryCalculators;
  };

  const categories = Object.keys(categoryInfo) as Array<keyof typeof categoryInfo>;

  return (
    <div className="space-y-16">
      {categories.map((category) => {
        const filteredCalculators = getFilteredCalculators(category);
        if (searchQuery && filteredCalculators.length === 0) return null;

        const info = categoryInfo[category];
        const IconComponent = info.icon;

        return (
          <section key={category} id={category}>
            <div className="flex items-center mb-6">
              <div className={`w-8 h-8 ${info.bgColor} rounded-lg flex items-center justify-center mr-3`}>
                <IconComponent className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-slate-900">{info.title}</h3>
                <p className="text-slate-600 text-sm">{info.description}</p>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredCalculators.map((calculator) => {
                const IconComp = calculator.icon;
                return (
                  <Link key={calculator.id} href={calculator.path}>
                    <Card className="cursor-pointer group hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
                      <CardContent className="p-6">
                        <div className="flex items-center mb-3">
                          <IconComp className={`text-${info.color} text-xl mr-3 h-5 w-5`} />
                          <h4 className={`font-semibold text-slate-900 group-hover:text-${info.color} transition-colors`}>
                            {calculator.name}
                          </h4>
                        </div>
                        <p className="text-slate-600 text-sm mb-3 line-clamp-2">
                          {calculator.description}
                        </p>
                        <div className="flex justify-between items-center">
                          <div className="flex gap-1">
                            {calculator.popular && (
                              <Badge variant="secondary" className="text-xs">
                                ⭐ Popular
                              </Badge>
                            )}
                            {calculator.trending && (
                              <Badge variant="secondary" className="text-xs">
                                🔥 Trending
                              </Badge>
                            )}
                          </div>
                          <Badge 
                            variant="outline" 
                            className={`text-${info.color} border-${info.color}/20 bg-${info.color}/5`}
                          >
                            {info.title.split(' ')[0]}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>

            <div className="mt-6 text-center">
              <Link href={`/category/${category}`}>
                <span className={`text-${info.color} hover:underline font-medium cursor-pointer`}>
                  View All {info.title} ({getCalculatorsByCategory(category).length}+) →
                </span>
              </Link>
            </div>
          </section>
        );
      })}
    </div>
  );
}
