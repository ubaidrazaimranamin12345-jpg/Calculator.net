import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BasicCalculator } from "@/lib/calculator-utils";

export default function CalculatorWidget() {
  const [display, setDisplay] = useState("0");
  const [expression, setExpression] = useState("");
  const [isNewNumber, setIsNewNumber] = useState(true);

  const handleNumber = (num: string) => {
    if (isNewNumber) {
      setDisplay(num);
      setIsNewNumber(false);
    } else {
      setDisplay(display === "0" ? num : display + num);
    }
  };

  const handleOperator = (op: string) => {
    const newExpression = expression + (expression ? ` ${op} ` : display + ` ${op} `);
    setExpression(newExpression);
    setIsNewNumber(true);
  };

  const handleFunction = (func: string) => {
    try {
      let result: number;
      const current = parseFloat(display);
      
      switch (func) {
        case "sin":
          result = Math.sin(current * Math.PI / 180);
          break;
        case "cos":
          result = Math.cos(current * Math.PI / 180);
          break;
        case "tan":
          result = Math.tan(current * Math.PI / 180);
          break;
        case "√":
          result = Math.sqrt(current);
          break;
        case "x²":
          result = current * current;
          break;
        case "π":
          result = Math.PI;
          break;
        default:
          return;
      }
      
      setDisplay(BasicCalculator.formatNumber(result));
      setExpression("");
      setIsNewNumber(true);
    } catch (error) {
      setDisplay("Error");
      setExpression("");
      setIsNewNumber(true);
    }
  };

  const handleEquals = () => {
    try {
      const fullExpression = expression + display;
      const result = BasicCalculator.evaluate(fullExpression);
      setDisplay(BasicCalculator.formatNumber(result));
      setExpression("");
      setIsNewNumber(true);
    } catch (error) {
      setDisplay("Error");
      setExpression("");
      setIsNewNumber(true);
    }
  };

  const handleClear = () => {
    setDisplay("0");
    setExpression("");
    setIsNewNumber(true);
  };

  const handleDecimal = () => {
    if (isNewNumber) {
      setDisplay("0.");
      setIsNewNumber(false);
    } else if (!display.includes(".")) {
      setDisplay(display + ".");
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Basic Calculator</CardTitle>
      </CardHeader>
      <CardContent>
        {/* Display */}
        <div className="bg-slate-900 text-white text-right p-4 rounded-lg mb-4">
          <div className="text-sm text-slate-400 h-6 min-h-[24px]">
            {expression || " "}
          </div>
          <div className="text-3xl font-mono break-all">
            {display}
          </div>
        </div>

        {/* Button Grid */}
        <div className="grid grid-cols-4 gap-2">
          {/* Row 1: Scientific functions */}
          <Button 
            className="calculator-button-function" 
            onClick={() => handleFunction("sin")}
          >
            sin
          </Button>
          <Button 
            className="calculator-button-function" 
            onClick={() => handleFunction("cos")}
          >
            cos
          </Button>
          <Button 
            className="calculator-button-function" 
            onClick={() => handleFunction("tan")}
          >
            tan
          </Button>
          <Button 
            className="calculator-button-clear" 
            onClick={handleClear}
          >
            C
          </Button>

          {/* Row 2: More functions */}
          <Button 
            className="calculator-button-function" 
            onClick={() => handleFunction("π")}
          >
            π
          </Button>
          <Button 
            className="calculator-button-function" 
            onClick={() => handleFunction("√")}
          >
            √
          </Button>
          <Button 
            className="calculator-button-function" 
            onClick={() => handleFunction("x²")}
          >
            x²
          </Button>
          <Button 
            className="calculator-button-operator" 
            onClick={() => handleOperator("/")}
          >
            ÷
          </Button>

          {/* Row 3: Numbers */}
          <Button 
            className="calculator-button-number" 
            onClick={() => handleNumber("7")}
          >
            7
          </Button>
          <Button 
            className="calculator-button-number" 
            onClick={() => handleNumber("8")}
          >
            8
          </Button>
          <Button 
            className="calculator-button-number" 
            onClick={() => handleNumber("9")}
          >
            9
          </Button>
          <Button 
            className="calculator-button-operator" 
            onClick={() => handleOperator("*")}
          >
            ×
          </Button>

          {/* Row 4: Numbers */}
          <Button 
            className="calculator-button-number" 
            onClick={() => handleNumber("4")}
          >
            4
          </Button>
          <Button 
            className="calculator-button-number" 
            onClick={() => handleNumber("5")}
          >
            5
          </Button>
          <Button 
            className="calculator-button-number" 
            onClick={() => handleNumber("6")}
          >
            6
          </Button>
          <Button 
            className="calculator-button-operator" 
            onClick={() => handleOperator("-")}
          >
            −
          </Button>

          {/* Row 5: Numbers */}
          <Button 
            className="calculator-button-number" 
            onClick={() => handleNumber("1")}
          >
            1
          </Button>
          <Button 
            className="calculator-button-number" 
            onClick={() => handleNumber("2")}
          >
            2
          </Button>
          <Button 
            className="calculator-button-number" 
            onClick={() => handleNumber("3")}
          >
            3
          </Button>
          <Button 
            className="calculator-button-operator" 
            onClick={() => handleOperator("+")}
          >
            +
          </Button>

          {/* Row 6: Zero, decimal, equals */}
          <Button 
            className="calculator-button-number col-span-2" 
            onClick={() => handleNumber("0")}
          >
            0
          </Button>
          <Button 
            className="calculator-button-number" 
            onClick={handleDecimal}
          >
            .
          </Button>
          <Button 
            className="calculator-button-equals" 
            onClick={handleEquals}
          >
            =
          </Button>
        </div>

        <div className="mt-4 text-center">
          <Button variant="link" className="text-primary text-sm">
            Switch to Scientific Calculator →
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
