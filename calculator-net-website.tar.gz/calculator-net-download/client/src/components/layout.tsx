import { Link, useLocation } from "wouter";
import { Search, Menu, Calculator } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks = [
    { href: "/#financial", label: "Financial" },
    { href: "/#health", label: "Health & Fitness" },
    { href: "/#math", label: "Math" },
    { href: "/#other", label: "Other" },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center">
              <Calculator className="h-8 w-8 text-primary mr-2" />
              <h1 className="text-2xl font-bold text-primary">Calculator.net</h1>
              <span className="ml-3 text-sm text-slate-500 hidden sm:inline">
                Free Online Calculators
              </span>
            </Link>

            <nav className="hidden md:flex space-x-8">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="text-slate-600 hover:text-primary transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>

          {/* Mobile menu */}
          {isMenuOpen && (
            <div className="md:hidden border-t border-slate-200 py-4">
              <nav className="flex flex-col space-y-2">
                {navLinks.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    className="text-slate-600 hover:text-primary transition-colors px-2 py-1"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {link.label}
                  </a>
                ))}
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main>{children}</main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-white font-semibold mb-4">Calculator.net</h3>
              <p className="text-sm mb-4">
                Free online calculators for all your math, financial, health, and everyday calculation needs.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Popular Calculators</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/calculator/bmi" className="hover:text-white transition-colors">
                    BMI Calculator
                  </Link>
                </li>
                <li>
                  <Link href="/calculator/mortgage" className="hover:text-white transition-colors">
                    Mortgage Calculator
                  </Link>
                </li>
                <li>
                  <Link href="/calculator/percentage" className="hover:text-white transition-colors">
                    Percentage Calculator
                  </Link>
                </li>
                <li>
                  <Link href="/calculator/age" className="hover:text-white transition-colors">
                    Age Calculator
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Categories</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="/#financial" className="hover:text-white transition-colors">
                    Financial
                  </a>
                </li>
                <li>
                  <a href="/#health" className="hover:text-white transition-colors">
                    Health & Fitness
                  </a>
                </li>
                <li>
                  <a href="/#math" className="hover:text-white transition-colors">
                    Math
                  </a>
                </li>
                <li>
                  <a href="/#other" className="hover:text-white transition-colors">
                    Other Utilities
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white transition-colors">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white transition-colors">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-sm">
            <p>&copy; 2024 Calculator.net. All rights reserved. Operated by Maple Tech International LLC.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
