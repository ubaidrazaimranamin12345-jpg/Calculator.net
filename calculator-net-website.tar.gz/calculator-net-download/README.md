# Calculator.net Clone - Complete Website Code

## 🧮 Project Overview

This is a comprehensive clone of Calculator.net featuring over 16+ different calculators across 4 main categories. Built with modern web technologies including React, TypeScript, Tailwind CSS, and Express.js.

## ✨ Features

### Calculator Categories

**📊 Financial Calculators**
- Mortgage Calculator - Monthly payments, interest, amortization
- Auto Loan Calculator - Car loan payments and total costs
- Interest Calculator - Simple and compound interest
- Retirement Calculator - Retirement planning and savings

**💪 Health & Fitness Calculators**
- BMI Calculator - Body Mass Index with health categories
- Calorie Calculator - Daily calorie needs for weight goals
- BMR Calculator - Basal Metabolic Rate calculations
- Pregnancy Calculator - Due dates and milestones

**🔢 Math Calculators**
- Percentage Calculator - Various percentage calculations
- Fraction Calculator - Fraction arithmetic operations
- Scientific Calculator - Advanced mathematical functions
- Triangle Calculator - Triangle geometry calculations

**🔧 Other Utility Calculators**
- Age Calculator - Exact age in years, months, days
- Date Calculator - Date arithmetic and calculations
- GPA Calculator - Grade Point Average calculations
- Password Generator - Secure password generation

### Technical Features

- **Responsive Design** - Mobile-first approach with Tailwind CSS
- **Search Functionality** - Global search across all calculators
- **Category Organization** - Color-coded categories for easy navigation
- **Real-time Calculations** - Instant results with form validation
- **Professional UI** - Clean, modern design matching Calculator.net
- **TypeScript** - Full type safety and better development experience

## 🚀 Quick Start

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn

### Installation

1. **Extract the files** to your desired directory
2. **Install dependencies**:
   ```bash
   npm install
   ```
3. **Start development server**:
   ```bash
   npm run dev
   ```
4. **Open your browser** and visit `http://localhost:5000`

### Build for Production

```bash
npm run build
```

## 📁 Project Structure

```
calculator-net-clone/
├── client/                     # Frontend React app
│   ├── src/
│   │   ├── components/         # Reusable UI components
│   │   │   ├── ui/            # Shadcn/UI components
│   │   │   ├── layout.tsx     # Main layout wrapper
│   │   │   ├── calculator-widget.tsx
│   │   │   └── calculator-categories.tsx
│   │   ├── pages/             # Page components
│   │   │   ├── home.tsx       # Homepage
│   │   │   ├── calculator-page.tsx
│   │   │   └── not-found.tsx
│   │   ├── lib/               # Utility libraries
│   │   │   ├── calculator-data.ts    # Calculator definitions
│   │   │   ├── calculator-utils.ts   # Mathematical logic
│   │   │   ├── utils.ts              # Helper functions
│   │   │   └── queryClient.ts        # API client
│   │   ├── hooks/             # Custom React hooks
│   │   ├── App.tsx            # Main app component
│   │   ├── main.tsx           # Entry point
│   │   └── index.css          # Global styles
│   └── index.html             # HTML template
├── server/                     # Backend Express server
│   ├── index.ts               # Server entry point
│   ├── routes.ts              # API routes
│   ├── storage.ts             # Data storage interface
│   └── vite.ts                # Vite integration
├── shared/                     # Shared type definitions
│   └── schema.ts
├── package.json               # Dependencies and scripts
├── vite.config.ts            # Vite configuration
├── tailwind.config.ts        # Tailwind CSS config
├── tsconfig.json             # TypeScript configuration
└── README.md                 # This file
```

## 🛠️ Technology Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS + Shadcn/UI
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack Query (React Query)
- **Forms**: React Hook Form + Zod validation
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL + Drizzle ORM (optional)
- **Icons**: Lucide React

## 🎨 Design System

### Colors
- **Financial**: Blue (`hsl(217 78% 56%)`)
- **Health**: Green (`hsl(159 100% 36%)`)
- **Math**: Purple (`hsl(271 76% 53%)`)
- **Other**: Orange (`hsl(24 100% 51%)`)

### Components
- Consistent UI components using Radix UI primitives
- Custom calculator button styles with hover effects
- Responsive grid layouts for calculator categories
- Professional form designs with validation states

## 🧮 Calculator Implementation

Each calculator is implemented with:

1. **Data Definition** (`calculator-data.ts`)
   ```typescript
   {
     id: 'mortgage',
     name: 'Mortgage Calculator',
     description: 'Calculate monthly mortgage payments...',
     category: 'financial',
     icon: Home,
     popular: true,
     path: '/calculator/mortgage'
   }
   ```

2. **Mathematical Logic** (`calculator-utils.ts`)
   ```typescript
   export class FinancialCalculator {
     static calculateMortgage(principal, rate, years) {
       // Mathematical implementation
     }
   }
   ```

3. **Form Implementation** (`calculator-page.tsx`)
   - React Hook Form for form handling
   - Zod validation for input validation
   - Dynamic result rendering based on calculator type

## 🔧 Customization

### Adding New Calculators

1. **Add to calculator data**:
   ```typescript
   // In calculator-data.ts
   {
     id: 'new-calculator',
     name: 'New Calculator',
     description: 'Description...',
     category: 'math',
     icon: Calculator,
     path: '/calculator/new-calculator'
   }
   ```

2. **Implement calculation logic**:
   ```typescript
   // In calculator-utils.ts
   export class MathCalculator {
     static calculateNew(param1, param2) {
       // Your calculation logic
       return result;
     }
   }
   ```

3. **Add form and results in calculator-page.tsx**

### Styling Modifications

- Update CSS variables in `client/src/index.css`
- Modify Tailwind config in `tailwind.config.ts`
- Customize component styles in individual files

## 📦 Deployment

### Replit Deployment
1. Upload all files to Replit
2. Install dependencies: `npm install`
3. Start the application: `npm run dev`

### Other Platforms
- **Vercel**: Connect your repository and deploy
- **Netlify**: Drag and drop the built files
- **Railway**: Connect repository for automatic deployment

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is open source and available under the MIT License.

## 🆘 Support

If you encounter any issues or have questions:

1. Check the console for error messages
2. Ensure all dependencies are installed correctly
3. Verify Node.js version compatibility
4. Check that all required environment variables are set

## 🎯 Key Files to Understand

- `client/src/lib/calculator-data.ts` - All calculator definitions
- `client/src/lib/calculator-utils.ts` - Mathematical calculation logic
- `client/src/pages/home.tsx` - Homepage with search and categories
- `client/src/pages/calculator-page.tsx` - Individual calculator pages
- `client/src/components/calculator-widget.tsx` - Basic calculator widget

Happy calculating! 🧮✨